function changeColorToRed() {
    let p =
        document.querySelector("p");
    p.style.color = "red";
}
function changeColorToGreen() {
    let p =
        document.querySelector("p");
    p.style.color = "green";
}
function changeColorToYellow() {
    let p =
        document.querySelector("p");
    p.style.color = "yellow";
}