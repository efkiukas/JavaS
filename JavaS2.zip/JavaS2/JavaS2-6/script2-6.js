function myFunction() {
    let newH3 =
        document.createElement("h1");
    newH3.textContent = "Pavadinimas";
    
    let div =
        document.querySelector("div");
    let parent = 
        document.querySelector("body");
    
    parent.insertBefore(newH3, div);
}