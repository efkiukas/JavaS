function myFunction() {
    let div =
        document.querySelector("div");
    div.style.visibility="visible";
}
function myFunction1() {
  alert("Hello! I am an alert box!");
}