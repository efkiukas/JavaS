function changeToKaireje() {
    let img =
        document.querySelector("img");
    img.setAttribute("class", "left");
}
function changeToDesineje() {
    let img =
        document.querySelector("img");
    img.setAttribute("class", "right");
}
function changeToPaslepti() {
    let img =
        document.querySelector("img");
    img.setAttribute("class", "visability");
}
function changeToPo() {
    let img =
        document.querySelector("img");
    img.setAttribute("class", "bottom");
}
function changeToAtstatyti() {
    let img =
        document.querySelector("img");
    img.removeAttribute("class");
}