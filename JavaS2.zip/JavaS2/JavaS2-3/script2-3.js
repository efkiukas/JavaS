function changeToJuoda() {
    let img =
        document.querySelector("img");
    img.style.filter = "grayscale(100%)";
}
function changeToSpalva() {
    let img =
        document.querySelector("img");
    img.style.filter = "grayscale(0%)";
}