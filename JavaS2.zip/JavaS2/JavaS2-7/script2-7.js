function myFunction() {
    let p =
        document.getElementById('p1').textContent = 'This text is different!';
    
    let h5 =
     document.getElementById('title').textContent = 'Hello';
    
    let img = document.getElementById("myImage").src = "image2.jpg";
}