function changeToMin() {
    let img =
        document.querySelector("img");
    img.style.width = "300px";
}
function changeToMax() {
    let img =
        document.querySelector("img");
    img.style.width = "600px";
}